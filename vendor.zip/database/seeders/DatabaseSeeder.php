<?php

namespace Database\Seeders;
use App\Models\Role;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;
    public function run(): void
    {
        $this->call(RoleSeeder::class);
        $this->call(LookupSeeder::class);
        $this->call(KeralachurchSeeder::class);
        $this->call(EventSeeder::class);
        $this->call(MarketplaceDemoSeeder::class);
        $this->call(MarketplaceCatalogSeeder::class);


        User::firstOrCreate(
            ['email' => 'admin@ibncc.com'],
            [
                'role_id' => Role::where('name', 'admin')->first()->id,
                'name' => 'Admin',
                'password' => 'admin@123',
            ]
        );
    }
}
