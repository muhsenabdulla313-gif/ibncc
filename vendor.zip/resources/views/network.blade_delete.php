
            <a href="index.html#about" class="nav-link" data-section="about">
              <span class="nav-mobile-icon" aria-hidden="true"
                ><i class="fa-solid fa-circle-info"></i
              ></span>
              <span class="nav-mobile-copy">
                <strong>About</strong>
                <em>Know more about us</em>
              </span>
              <i
                class="fa-solid fa-chevron-right nav-mobile-chevron"
                aria-hidden="true"
              ></i>
            </a>
            <a href="index.html#events" class="nav-link" data-section="events">
              <span class="nav-mobile-icon" aria-hidden="true"
                ><i class="fa-solid fa-calendar-days"></i
              ></span>
              <span class="nav-mobile-copy">
                <strong>Events</strong>
                <em>Upcoming gatherings</em>
              </span>
              <i
                class="fa-solid fa-chevron-right nav-mobile-chevron"
                aria-hidden="true"
              ></i>
            </a>
            <a
              href="networking.html"
              class="nav-link active"
              data-section="networking"
            >
              <span class="nav-mobile-icon" aria-hidden="true"
                ><i class="fa-solid fa-handshake"></i
              ></span>
              <span class="nav-mobile-copy">
                <strong>Networking</strong>
                <em>Build global connections</em>
              </span>
              <i
                class="fa-solid fa-chevron-right nav-mobile-chevron"
                aria-hidden="true"
              ></i>
            </a>
            <a href="ch-trading.html" class="nav-link" data-section="trading">
              <span class="nav-mobile-icon" aria-hidden="true"
                ><i class="fa-solid fa-arrow-right-arrow-left"></i
              ></span>
              <span class="nav-mobile-copy">
                <strong>Trading</strong>
                <em>Collaborate and grow</em>
              </span>
              <i
                class="fa-solid fa-chevron-right nav-mobile-chevron"
                aria-hidden="true"
              ></i>
            </a>
          </div>
        </div>
      </nav>
    </header>

    <main>
      <!-- ========== NETWORKING SECTION (from CC_Hub ch-home.html, wrapped in ch-scope) ========== -->
      <div class="ch-scope">
        <section
          class="networking-section"
          id="networking"
          aria-labelledby="networking-heading"
        >
          <div class="networking-hero-bar">
            <div class="networking-hero-inner">
              <div class="networking-brand">
                <span class="networking-brand-icon" aria-hidden="true">
                  <i class="fa-solid fa-share-nodes"></i>
                </span>
                <div>
                  <h2 id="networking-heading" class="networking-brand-title">
                    Networking
                  </h2>
                  <p class="networking-brand-tagline">
                    Connect. Collaborate. Grow Together.
                  </p>
                </div>
              </div>

              <form
                class="networking-search"
                role="search"
                aria-label="Search profiles"
              >
                <input
                  type="search"
                  placeholder="Search by name, profession or service..."
                  aria-label="Search by name, profession or service"
                />
                <button
                  type="submit"
                  class="networking-search-btn"
                  aria-label="Search"
                >
                  <i class="fa-solid fa-magnifying-glass"></i>
                </button>
              </form>

              <div class="networking-location-group">
                <button
                  type="button"
                  class="networking-location"
                  aria-label="Change location"
                >
                  <i class="fa-solid fa-location-dot" aria-hidden="true"></i>
                  <span>
                    <small>Current Location:</small>
                    Kozhikode, Kerala, India
                  </span>
                  <i class="fa-solid fa-chevron-down" aria-hidden="true"></i>
                </button>
                <a
                  href="ch-profile.html"
                  class="app-nav-icon app-nav-icon--profile networking-profile-icon"
                  aria-label="Your profile"
                  title="Your profile"
                >
                  <i class="fa-regular fa-user" aria-hidden="true"></i>
                </a>
              </div>
            </div>
          </div>

          <div class="networking-body">
            <aside class="networking-filters" aria-label="Profile filters">
              <header class="filters-header">
                <div class="filters-header-top">
                  <i class="fa-solid fa-sliders" aria-hidden="true"></i>
                  <h3>Filters</h3>
                </div>
                <p>Refine your search to find the right connections.</p>
              </header>

              <div class="filter-group">
                <h4 class="filter-group-title">
                  <i class="fa-solid fa-location-dot" aria-hidden="true"></i>
                  Location
                </h4>
                <div class="filter-fields">
                  <label class="filter-select">
                    <span class="visually-hidden">Country</span>
                    <select>
                      <option>Country</option>
                      <option selected>India</option>
                      <option>UAE</option>
                      <option>USA</option>
                    </select>
                  </label>
                  <label class="filter-select">
                    <span class="visually-hidden">State</span>
                    <select>
                      <option>State</option>
                      <option selected>Kerala</option>
                      <option>Karnataka</option>
                      <option>Tamil Nadu</option>
                    </select>
                  </label>
                  <label class="filter-select">
                    <span class="visually-hidden">District</span>
                    <select>
                      <option>District</option>
                      <option selected>Kozhikode</option>
                      <option>Ernakulam</option>
                      <option>Thrissur</option>
                    </select>
                  </label>
                </div>
              </div>

              <div class="filter-group">
                <h4 class="filter-group-title">
                  <i class="fa-solid fa-church" aria-hidden="true"></i>
                  Church Hierarchy
                </h4>
                <div class="filter-fields">
                  <label class="filter-select">
                    <span class="visually-hidden">Rite</span>
                    <select>
                      <option>Rite</option>
                      <option selected>Syro-Malabar</option>
                      <option>Latin</option>
                      <option>Syro-Malankara</option>
                    </select>
                  </label>
                  <label class="filter-select">
                    <span class="visually-hidden">Diocese</span>
                    <select>
                      <option>Diocese</option>
                      <option selected>Thamarassery</option>
                      <option>Calicut</option>
                      <option>Tellicherry</option>
                    </select>
                  </label>
                  <label class="filter-select">
                    <span class="visually-hidden">Forane</span>
                    <select>
                      <option>Forane</option>
                      <option selected>Kozhikode Forane</option>
                      <option>Balussery Forane</option>
                    </select>
                  </label>
                  <label class="filter-select">
                    <span class="visually-hidden">Parish</span>
                    <select>
                      <option>Parish</option>
                      <option selected>St. Mary&apos;s Cathedral</option>
                      <option>Sacred Heart Church</option>
                    </select>
                  </label>
                </div>
              </div>

              <div class="filter-group">
                <h4 class="filter-group-title">
                  <i class="fa-solid fa-briefcase" aria-hidden="true"></i>
                  Employment Status
                </h4>
                <label class="filter-select filter-select-full">
                  <span class="visually-hidden">Employment Status</span>
                  <select>
                    <option>Select status</option>
                    <option selected>Employed</option>
                    <option>Self-employed</option>
                    <option>Student</option>
                    <option>Seeking opportunities</option>
                  </select>
                </label>
              </div>

              <div class="filter-group">
                <h4 class="filter-group-title">
                  <i class="fa-solid fa-toolbox" aria-hidden="true"></i>
                  Job / Profession
                </h4>
                <label class="filter-select filter-select-full">
                  <span class="visually-hidden">Job / Profession</span>
                  <select>
                    <option>Select profession</option>
                    <option selected>Civil Engineer</option>
                    <option>Physician</option>
                    <option>Teacher</option>
                    <option>Entrepreneur</option>
                  </select>
                </label>
              </div>

              <div class="filter-official">
                <div class="filter-official-copy">
                  <i class="fa-solid fa-lock" aria-hidden="true"></i>
                  <div>
                    <strong>Filter Official</strong>
                    <span>Access restricted to administrators only</span>
                  </div>
                </div>
                <label class="toggle-switch">
                  <input
                    id="officialFilterToggle"
                    type="checkbox"
                    aria-label="Filter Official"
                    aria-controls="officialExtraFilters"
                  />
                  <span class="toggle-slider" aria-hidden="true"></span>
                </label>
              </div>

              <div
                class="official-extra-filters"
                id="officialExtraFilters"
                hidden
              >
                <div class="filter-group">
                  <h4 class="filter-group-title">
                    <i
                      class="fa-solid fa-hourglass-half"
                      aria-hidden="true"
                    ></i>
                    Age
                    <span class="filter-age-value" id="officialAgeValue"
                      >40 years</span
                    >
                  </h4>
                  <div class="filter-age-range">
                    <span>18</span>
                    <input
                      id="officialAgeRange"
                      type="range"
                      min="18"
                      max="80"
                      value="40"
                      aria-label="Age"
                    />
                    <span>80</span>
                  </div>
                </div>

                <div class="filter-fields official-extra-grid">
                  <div class="filter-group">
                    <h4 class="filter-group-title">
                      <i class="fa-solid fa-venus-mars" aria-hidden="true"></i>
                      Gender
                    </h4>
                    <label class="filter-select">
                      <span class="visually-hidden">Gender</span>
                      <select id="officialGender">
                        <option selected>Select gender</option>
                        <option>Male</option>
                        <option>Female</option>
                        <option>Others</option>
                      </select>
                    </label>
                  </div>

                  <div class="filter-group">
                    <h4 class="filter-group-title">
                      <i class="fa-solid fa-droplet" aria-hidden="true"></i>
                      Blood Group
                    </h4>
                    <label class="filter-select">
                      <span class="visually-hidden">Blood Group</span>
                      <select id="officialBloodGroup">
                        <option selected>Select blood group</option>
                        <option>A+</option>
                        <option>A-</option>
                        <option>B+</option>
                        <option>B-</option>
                        <option>AB+</option>
                        <option>AB-</option>
                        <option>O+</option>
                        <option>O-</option>
                      </select>
                    </label>
                  </div>

                  <div class="filter-group">
                    <h4 class="filter-group-title">
                      <i class="fa-solid fa-layer-group" aria-hidden="true"></i>
                      Job Category
                    </h4>
                    <label class="filter-select">
                      <span class="visually-hidden">Job Category</span>
                      <select
                        id="officialJobCategory"
                        aria-label="Category options"
                      >
                        <option value="" selected>Select category</option>
                        <option>Hospitality &amp; Personal Services</option>
                        <option>Healthcare &amp; Medical</option>
                        <option>Engineering &amp; Technical</option>
                        <option>Education &amp; Research</option>
                        <option>Business &amp; Finance</option>
                        <option>Information Technology (IT)</option>
                        <option>Construction &amp; Skilled Trades</option>
                        <option>Agriculture &amp; Food</option>
                        <option>Business, Sales &amp; Marketing</option>
                        <option>Government, Legal &amp; Public Service</option>
                        <option>Arts, Media &amp; Design</option>
                        <option>Transportation &amp; Logistics</option>
                      </select>
                    </label>
                  </div>

                  <div class="filter-group">
                    <h4 class="filter-group-title">
                      <i class="fa-solid fa-user-tie" aria-hidden="true"></i>
                      Job
                    </h4>
                    <label class="filter-select">
                      <span class="visually-hidden">Job</span>
                      <select id="officialJob">
                        <option value="" selected>Select job</option>
                        <option
                          data-category="Hospitality &amp; Personal Services"
                        >
                          Hotel Manager
                        </option>
                        <option
                          data-category="Hospitality &amp; Personal Services"
                        >
                          Receptionist
                        </option>
                        <option
                          data-category="Hospitality &amp; Personal Services"
                        >
                          Beautician
                        </option>
                        <option
                          data-category="Hospitality &amp; Personal Services"
                        >
                          Hair Stylist
                        </option>
                        <option
                          data-category="Hospitality &amp; Personal Services"
                        >
                          Tour Guide
                        </option>
                        <option
                          data-category="Hospitality &amp; Personal Services"
                        >
                          Housekeeper
                        </option>
                        <option
                          data-category="Hospitality &amp; Personal Services"
                        >
                          Event Manager
                        </option>
                        <option data-category="Healthcare &amp; Medical">
                          Doctor
                        </option>
                        <option data-category="Healthcare &amp; Medical">
                          Nurse
                        </option>
                        <option data-category="Healthcare &amp; Medical">
                          Dentist
                        </option>
                        <option data-category="Healthcare &amp; Medical">
                          Pharmacist
                        </option>
                        <option data-category="Healthcare &amp; Medical">
                          Surgeon
                        </option>
                        <option data-category="Healthcare &amp; Medical">
                          Physiotherapist
                        </option>
                        <option data-category="Healthcare &amp; Medical">
                          Lab Technician
                        </option>
                        <option data-category="Healthcare &amp; Medical">
                          Psychologist
                        </option>
                        <option data-category="Engineering &amp; Technical">
                          Civil Engineer
                        </option>
                        <option data-category="Engineering &amp; Technical">
                          Mechanical Engineer
                        </option>
                        <option data-category="Engineering &amp; Technical">
                          Electrical Engineer
                        </option>
                        <option data-category="Engineering &amp; Technical">
                          Software Engineer
                        </option>
                        <option data-category="Engineering &amp; Technical">
                          Architect
                        </option>
                        <option data-category="Engineering &amp; Technical">
                          Surveyor
                        </option>
                        <option data-category="Engineering &amp; Technical">
                          Technician
                        </option>
                        <option data-category="Education &amp; Research">
                          Teacher
                        </option>
                        <option data-category="Education &amp; Research">
                          Professor
                        </option>
                        <option data-category="Education &amp; Research">
                          Lecturer
                        </option>
                        <option data-category="Education &amp; Research">
                          Tutor
                        </option>
                        <option data-category="Education &amp; Research">
                          Researcher
                        </option>
                        <option data-category="Education &amp; Research">
                          Librarian
                        </option>
                        <option data-category="Business &amp; Finance">
                          Accountant
                        </option>
                        <option data-category="Business &amp; Finance">
                          Banker
                        </option>
                        <option data-category="Business &amp; Finance">
                          Financial Analyst
                        </option>
                        <option data-category="Business &amp; Finance">
                          Auditor
                        </option>
                        <option data-category="Business &amp; Finance">
                          Insurance Agent
                        </option>
                        <option data-category="Business &amp; Finance">
                          Investment Advisor
                        </option>
                        <option data-category="Information Technology (IT)">
                          Web Developer
                        </option>
                        <option data-category="Information Technology (IT)">
                          App Developer
                        </option>
                        <option data-category="Information Technology (IT)">
                          UI/UX Designer
                        </option>
                        <option data-category="Information Technology (IT)">
                          Data Scientist
                        </option>
                        <option data-category="Information Technology (IT)">
                          Cybersecurity Expert
                        </option>
                        <option data-category="Information Technology (IT)">
                          Network Engineer
                        </option>
                        <option
                          data-category="Construction &amp; Skilled Trades"
                        >
                          Electrician
                        </option>
                        <option
                          data-category="Construction &amp; Skilled Trades"
                        >
                          Plumber
                        </option>
                        <option
                          data-category="Construction &amp; Skilled Trades"
                        >
                          Carpenter
                        </option>
                        <option
                          data-category="Construction &amp; Skilled Trades"
                        >
                          Mason
                        </option>
                        <option
                          data-category="Construction &amp; Skilled Trades"
                        >
                          Welder
                        </option>
                        <option
                          data-category="Construction &amp; Skilled Trades"
                        >
                          Painter
                        </option>
                        <option
                          data-category="Construction &amp; Skilled Trades"
                        >
                          HVAC Technician
                        </option>
                        <option data-category="Agriculture &amp; Food">
                          Farmer
                        </option>
                        <option data-category="Agriculture &amp; Food">
                          Gardener
                        </option>
                        <option data-category="Agriculture &amp; Food">
                          Dairy Farmer
                        </option>
                        <option data-category="Agriculture &amp; Food">
                          Fisherman
                        </option>
                        <option data-category="Agriculture &amp; Food">
                          Food Technologist
                        </option>
                        <option data-category="Agriculture &amp; Food">
                          Chef
                        </option>
                        <option data-category="Agriculture &amp; Food">
                          Baker
                        </option>
                        <option data-category="Business, Sales &amp; Marketing">
                          Sales Executive
                        </option>
                        <option data-category="Business, Sales &amp; Marketing">
                          Marketing Manager
                        </option>
                        <option data-category="Business, Sales &amp; Marketing">
                          Business Development Officer
                        </option>
                        <option data-category="Business, Sales &amp; Marketing">
                          Retail Manager
                        </option>
                        <option data-category="Business, Sales &amp; Marketing">
                          Customer Support
                        </option>
                        <option
                          data-category="Government, Legal &amp; Public Service"
                        >
                          Police Officer
                        </option>
                        <option
                          data-category="Government, Legal &amp; Public Service"
                        >
                          Lawyer
                        </option>
                        <option
                          data-category="Government, Legal &amp; Public Service"
                        >
                          Judge
                        </option>
                        <option
                          data-category="Government, Legal &amp; Public Service"
                        >
                          Army Officer
                        </option>
                        <option
                          data-category="Government, Legal &amp; Public Service"
                        >
                          Firefighter
                        </option>
                        <option
                          data-category="Government, Legal &amp; Public Service"
                        >
                          Government Officer
                        </option>
                        <option
                          data-category="Government, Legal &amp; Public Service"
                        >
                          Social Worker
                        </option>
                        <option data-category="Arts, Media &amp; Design">
                          Graphic Designer
                        </option>
                        <option data-category="Arts, Media &amp; Design">
                          Photographer
                        </option>
                        <option data-category="Arts, Media &amp; Design">
                          Musician
                        </option>
                        <option data-category="Arts, Media &amp; Design">
                          Actor
                        </option>
                        <option data-category="Arts, Media &amp; Design">
                          Writer
                        </option>
                        <option data-category="Arts, Media &amp; Design">
                          Video Editor
                        </option>
                        <option data-category="Arts, Media &amp; Design">
                          Animator
                        </option>
                        <option data-category="Arts, Media &amp; Design">
                          Fashion Designer
                        </option>
                        <option data-category="Transportation &amp; Logistics">
                          Driver
                        </option>
                        <option data-category="Transportation &amp; Logistics">
                          Pilot
                        </option>
                        <option data-category="Transportation &amp; Logistics">
                          Train Operator
                        </option>
                        <option data-category="Transportation &amp; Logistics">
                          Delivery Executive
                        </option>
                        <option data-category="Transportation &amp; Logistics">
                          Logistics Manager
                        </option>
                        <option data-category="Transportation &amp; Logistics">
                          Warehouse Supervisor
                        </option>
                      </select>
                    </label>
                  </div>
                </div>
              </div>

              <footer class="filters-footer">
                <div class="profiles-count-card">
                  <i class="fa-solid fa-users" aria-hidden="true"></i>
                  <div>
                    <span>Profiles Count</span>
                    <strong>124 profiles found</strong>
                  </div>
                </div>
                <button type="button" class="filters-results-btn">
                  <i
                    class="fa-solid fa-magnifying-glass"
                    aria-hidden="true"
                  ></i>
                  See Results
                </button>
              </footer>
            </aside>

            <div class="networking-results">
              <div class="results-toolbar">
                <p class="results-summary">
                  Showing profiles
                  <span class="results-badge">124 Results</span>
                </p>
                <label class="results-sort">
                  <span>Sort by:</span>
                  <select>
                    <option selected>Recently Added</option>
                    <option>Name A–Z</option>
                    <option>Nearest First</option>
                  </select>
                </label>
              </div>

              <ul class="profile-list">
                <li class="profile-card">
                  <div class="profile-main">
                    <img
                      class="profile-avatar"
                      src="assets/images/pr1.jpg"
                      alt="Portrait of George Mathew"
                      width="72"
                      height="72"
                    />
                    <div class="profile-info">
                      <h3 class="profile-name">
                        George Mathew
                        <i
                          class="fa-solid fa-circle-check"
                          title="Verified"
                          aria-label="Verified"
                        ></i>
                      </h3>
                      <p class="profile-role">Civil Engineer</p>
                      <p class="profile-bio">
                        Passionate about contributing to society through ethical
                        and sustainable design.
                      </p>
                      <p class="profile-status is-available">
                        <span class="status-dot" aria-hidden="true"></span>
                        Available
                      </p>
                    </div>
                  </div>
                  <div class="profile-location">
                    <i class="fa-solid fa-location-dot" aria-hidden="true"></i>
                    <div>
                      <strong>Kozhikode, Kerala</strong>
                      <span>Kozhikode District</span>
                    </div>
                  </div>
                  <div class="profile-contact">
                    <a href="tel:+919876543210"
                      ><i class="fa-solid fa-phone" aria-hidden="true"></i> +91
                      98765 43210</a
                    >
                    <a href="mailto:arun.mathew@email.com"
                      ><i class="fa-solid fa-envelope" aria-hidden="true"></i>
                      arun.mathew@email.com</a
                    >
                  </div>
                  <a
                    href="ch-other-profile.html"
                    class="profile-open"
                    aria-label="View George Mathew profile"
                  >
                    <i class="fa-solid fa-chevron-right" aria-hidden="true"></i>
                  </a>
                </li>

                <li class="profile-card">
                  <div class="profile-main">
                    <img
                      class="profile-avatar"
                      src="assets/images/lr1.jpg"
                      alt="Portrait of Dr. Meera Thomas"
                      width="72"
                      height="72"
                    />
                    <div class="profile-info">
                      <h3 class="profile-name">
                        Dr. Meera Thomas
                        <i
                          class="fa-solid fa-circle-check"
                          title="Verified"
                          aria-label="Verified"
                        ></i>
                      </h3>
                      <p class="profile-role">Physician</p>
                      <p class="profile-bio">
                        Community health advocate offering family care and
                        wellness guidance.
                      </p>
                      <p class="profile-status is-available">
                        <span class="status-dot" aria-hidden="true"></span>
                        Available
                      </p>
                    </div>
                  </div>
                  <div class="profile-location">
                    <i class="fa-solid fa-location-dot" aria-hidden="true"></i>
                    <div>
                      <strong>Ernakulam, Kerala</strong>
                      <span>Ernakulam District</span>
                    </div>
                  </div>
                  <div class="profile-contact">
                    <a href="tel:+919812345678"
                      ><i class="fa-solid fa-phone" aria-hidden="true"></i> +91
                      98123 45678</a
                    >
                    <a href="mailto:meera.thomas@email.com"
                      ><i class="fa-solid fa-envelope" aria-hidden="true"></i>
                      meera.thomas@email.com</a
                    >
                  </div>
                  <a
                    href="ch-other-profile.html"
                    class="profile-open"
                    aria-label="View Dr. Meera Thomas profile"
                  >
                    <i class="fa-solid fa-chevron-right" aria-hidden="true"></i>
                  </a>
                </li>

                <li class="profile-card">
                  <div class="profile-main">
                    <img
                      class="profile-avatar"
                      src="assets/images/pr2.jpg"
                      alt="Portrait of Joseph Kurian"
                      width="72"
                      height="72"
                    />
                    <div class="profile-info">
                      <h3 class="profile-name">
                        Joseph Kurian
                        <i
                          class="fa-solid fa-circle-check"
                          title="Verified"
                          aria-label="Verified"
                        ></i>
                      </h3>
                      <p class="profile-role">Entrepreneur</p>
                      <p class="profile-bio">
                        Builds local trade partnerships and mentors first-time
                        founders.
                      </p>
                      <p class="profile-status is-busy">
                        <span class="status-dot" aria-hidden="true"></span>
                        Busy
                      </p>
                    </div>
                  </div>
                  <div class="profile-location">
                    <i class="fa-solid fa-location-dot" aria-hidden="true"></i>
                    <div>
                      <strong>Thrissur, Kerala</strong>
                      <span>Thrissur District</span>
                    </div>
                  </div>
                  <div class="profile-contact">
                    <a href="tel:+919900112233"
                      ><i class="fa-solid fa-phone" aria-hidden="true"></i> +91
                      99001 12233</a
                    >
                    <a href="mailto:joseph.kurian@email.com"
                      ><i class="fa-solid fa-envelope" aria-hidden="true"></i>
                      joseph.kurian@email.com</a
                    >
                  </div>
                  <a
                    href="ch-other-profile.html"
                    class="profile-open"
                    aria-label="View Joseph Kurian profile"
                  >
                    <i class="fa-solid fa-chevron-right" aria-hidden="true"></i>
                  </a>
                </li>

                <li class="profile-card">
                  <div class="profile-main">
                    <img
                      class="profile-avatar"
                      src="assets/images/lr3.jpg"
                      alt="Portrait of Anitha George"
                      width="72"
                      height="72"
                    />
                    <div class="profile-info">
                      <h3 class="profile-name">
                        Anitha George
                        <i
                          class="fa-solid fa-circle-check"
                          title="Verified"
                          aria-label="Verified"
                        ></i>
                      </h3>
                      <p class="profile-role">Teacher</p>
                      <p class="profile-bio">
                        Educator focused on youth formation, literacy, and
                        community tutoring.
                      </p>
                      <p class="profile-status is-available">
                        <span class="status-dot" aria-hidden="true"></span>
                        Available
                      </p>
                    </div>
                  </div>
                  <div class="profile-location">
                    <i class="fa-solid fa-location-dot" aria-hidden="true"></i>
                    <div>
                      <strong>Kannur, Kerala</strong>
                      <span>Kannur District</span>
                    </div>
                  </div>
                  <div class="profile-contact">
                    <a href="tel:+919944556677"
                      ><i class="fa-solid fa-phone" aria-hidden="true"></i> +91
                      99445 56677</a
                    >
                    <a href="mailto:anitha.george@email.com"
                      ><i class="fa-solid fa-envelope" aria-hidden="true"></i>
                      anitha.george@email.com</a
                    >
                  </div>
                  <a
                    href="ch-other-profile.html"
                    class="profile-open"
                    aria-label="View Anitha George profile"
                  >
                    <i class="fa-solid fa-chevron-right" aria-hidden="true"></i>
                  </a>
                </li>
              </ul>

              <nav
                class="networking-pagination"
                aria-label="Profile results pages"
              >
                <button
                  type="button"
                  class="page-btn is-active"
                  aria-current="page"
                >
                  1
                </button>
                <button type="button" class="page-btn">2</button>
                <button type="button" class="page-btn">3</button>
                <span class="page-ellipsis" aria-hidden="true">…</span>
                <button type="button" class="page-btn">12</button>
                <button
                  type="button"
                  class="page-btn page-next"
                  aria-label="Next page"
                >
                  <i class="fa-solid fa-chevron-right"></i>
                </button>
              </nav>
            </div>
          </div>
        </section>
      </div>
    </main>

    <!-- ========== FOOTER ========== -->
    <footer class="site-footer" id="footer">
      <div class="footer-card">
        <div class="container footer-grid">
          <div class="footer-brand">
            <div class="footer-brand-inner">
              <img
                src="assets/images/logo_full.png"
                alt="IBNCC"
                width="56"
                height="56"
              />
              <div>
                <strong class="footer-tagline"
                  >International Business Network <br />
                  of Catholic Congress</strong
                >
                <!-- <span>International Business Network</span> -->
                <p>
                  A global platform connecting Catholic entrepreneurs,
                  professionals and organizations to collaborate, trade and grow
                  together.
                </p>
              </div>
            </div>
          </div>

          <!-- <div class="footer-nav">
          <h3>Navigate</h3>
          <a href="#home"><i class="fa-solid fa-house" aria-hidden="true"></i><span>Home</span></a>
          <a href="#about"><i class="fa-solid fa-circle-info" aria-hidden="true"></i><span>About</span></a>
          <a href="#events"><i class="fa-solid fa-calendar-days" aria-hidden="true"></i><span>Events</span></a>
          <a href="#networking"><i class="fa-solid fa-handshake" aria-hidden="true"></i><span>Networking</span></a>
          <a href="ch-trading.html"><i class="fa-solid fa-arrow-right-arrow-left"
              aria-hidden="true"></i><span>Trading</span></a>
        </div> -->
          <div class="footer-nav">
            <h3>Navigate</h3>
            <a href="#home"><span>Home</span></a>
            <a href="#about"><span>About</span></a>
            <a href="#events"><span>Events</span></a>
            <a href="#networking"><span>Networking</span></a>
            <a href="ch-trading.html"><span>Trading</span></a>
          </div>

          <div class="footer-connect">
            <h3>Connect</h3>
            <a href="mailto:ibncc26@gmail.com" class="footer-contact-link">
              <i class="fa-solid fa-envelope" aria-hidden="true"></i>
              <span>ibncc26@gmail.com</span>
            </a>
            <a href="tel:+10000000000" class="footer-contact-link">
              <i class="fa-solid fa-phone" aria-hidden="true"></i>
              <span>+91 9847030064</span>
            </a>
            <!-- <div class="footer-location">
            <i class="fa-solid fa-location-dot" aria-hidden="true"></i>
            <span>IBNCC Global Secretariat, Kochi, Kerala, India</span>
          </div> -->

            <h3 class="footer-follow">Follow Us</h3>
            <div class="socials" aria-label="Social links">
              <a href="#" aria-label="LinkedIn"
                ><i class="fa-brands fa-linkedin-in" aria-hidden="true"></i
              ></a>
              <a href="#" aria-label="X / Twitter"
                ><i class="fa-brands fa-x-twitter" aria-hidden="true"></i
              ></a>
              <a href="#" aria-label="Instagram"
                ><i class="fa-brands fa-instagram" aria-hidden="true"></i
              ></a>
              <a href="#" aria-label="Facebook"
                ><i class="fa-brands fa-facebook-f" aria-hidden="true"></i
              ></a>
            </div>
          </div>
        </div>

        <div class="container footer-bottom">
          <p class="footer-copy">&copy; 2026 IBNCC. All rights reserved.</p>
          <div class="footer-design">
            <a href="#">Designed By : Astraz Software solutions</a>
            <!-- <span aria-hidden="true">|</span>
          <a href="#">Terms of Service</a>
          <span aria-hidden="true">|</span>
          <a href="#">Sitemap</a> -->
          </div>
        </div>
      </div>
    </footer>

    <button
      type="button"
      class="back-to-top"
      id="back-to-top"
      aria-label="Back to top"
    >
      <i class="fa-solid fa-chevron-up" aria-hidden="true"></i>
    </button>

    <!-- ========== LOGIN MODALS (from CC_Hub ch-home.html) ========== -->
    <dialog class="login-modal" id="loginModal" aria-labelledby="login-title">
      <div class="login-card">
        <button
          type="button"
          class="login-modal-close"
          id="loginModalClose"
          aria-label="Close login"
        >
          <i class="fa-solid fa-xmark" aria-hidden="true"></i>
        </button>

        <header class="login-card-head">
          <span class="login-lock" aria-hidden="true">
            <i class="fa-solid fa-lock"></i>
          </span>
          <div>
            <h2 id="login-title">Login to IBNCC</h2>
            <p class="login-tagline">
              Connect<span>•</span>Trade<span>•</span>Grow
            </p>
          </div>
        </header>

        <form class="login-form" id="loginForm">
          <div class="login-field">
            <i
              class="fa-solid fa-phone login-field-icon"
              aria-hidden="true"
            ></i>
            <label class="visually-hidden" for="loginPhone">Phone Number</label>
            <input
              id="loginPhone"
              type="tel"
              name="phone"
              placeholder="Phone Number"
              autocomplete="tel"
              required
            />
          </div>

          <div class="login-field">
            <i class="fa-solid fa-lock login-field-icon" aria-hidden="true"></i>
            <label class="visually-hidden" for="loginPassword">Password</label>
            <input
              id="loginPassword"
              type="password"
              name="password"
              placeholder="Password"
              autocomplete="current-password"
              required
            />
            <button
              type="button"
              class="login-password-toggle"
              id="loginPasswordToggle"
              aria-label="Show password"
            >
              <i class="fa-regular fa-eye-slash" aria-hidden="true"></i>
            </button>
          </div>

          <div class="login-row">
            <label class="login-remember">
              <input type="checkbox" name="remember" />
              Remember me
            </label>
            <a href="#forgot-password" class="login-forgot">Forgot Password?</a>
          </div>

          <button type="submit" class="login-submit">
            Login
            <i class="fa-solid fa-right-to-bracket" aria-hidden="true"></i>
          </button>

          <div class="login-divider">or</div>

          <a href="#register" class="login-register">
            <i class="fa-solid fa-user-group" aria-hidden="true"></i>
            New Member? Register Here
          </a>
        </form>

        <div class="login-wave" aria-hidden="true">
          <svg viewBox="0 0 420 72" preserveAspectRatio="none">
            <path
              fill="#f3c43a"
              d="M0 26c48 22 86-16 138-4 54 12 78 36 132 26 50-8 82-30 150-6v30H0z"
            />
            <path
              fill="#e8a31a"
              d="M0 42c58 16 92-14 150-4 56 10 88 26 142 14 48-10 72-6 128 10v10H0z"
            />
            <path
              fill="#d97706"
              d="M0 58c72 10 112-8 182 2 56 8 92 12 238 2v10H0z"
            />
          </svg>
        </div>
      </div>
    </dialog>

    <dialog
      class="login-modal otp-modal"
      id="otpModal"
      aria-labelledby="otp-title"
    >
      <div class="login-card otp-card">
        <button
          type="button"
          class="login-modal-close"
          id="otpModalClose"
          aria-label="Close OTP verification"
        >
          <i class="fa-solid fa-xmark" aria-hidden="true"></i>
        </button>

        <header class="login-card-head">
          <span class="login-lock" aria-hidden="true">
            <i class="fa-solid fa-shield-halved"></i>
          </span>
          <div>
            <h2 id="otp-title">OTP Verification</h2>
            <p class="login-tagline">Verify your registered mobile</p>
          </div>
        </header>

        <p class="otp-sent-text">
          We've sent a 6-digit OTP to the mobile number associated with your
          signup account.
        </p>
        <p class="otp-phone">
          Sent to <span id="otpMaskedPhone">your registered mobile</span>
        </p>

        <div class="otp-sms" id="otpSms" hidden>
          <span class="otp-sms-label">Message from CC Hub</span>
          <p>
            Your OTP is <strong id="otpSmsCode"></strong>. Do not share this
            code with anyone.
          </p>
        </div>

        <form class="otp-form" id="otpForm">
          <div class="otp-inputs" role="group" aria-label="One-time password">
            <label class="visually-hidden" for="otpDigit1">Digit 1</label>
            <input
              id="otpDigit1"
              type="text"
              inputmode="numeric"
              maxlength="1"
              autocomplete="one-time-code"
              required
            />
            <label class="visually-hidden" for="otpDigit2">Digit 2</label>
            <input
              id="otpDigit2"
              type="text"
              inputmode="numeric"
              maxlength="1"
              required
            />
            <label class="visually-hidden" for="otpDigit3">Digit 3</label>
            <input
              id="otpDigit3"
              type="text"
              inputmode="numeric"
              maxlength="1"
              required
            />
            <label class="visually-hidden" for="otpDigit4">Digit 4</label>
            <input
              id="otpDigit4"
              type="text"
              inputmode="numeric"
              maxlength="1"
              required
            />
            <label class="visually-hidden" for="otpDigit5">Digit 5</label>
            <input
              id="otpDigit5"
              type="text"
              inputmode="numeric"
              maxlength="1"
              required
            />
            <label class="visually-hidden" for="otpDigit6">Digit 6</label>
            <input
              id="otpDigit6"
              type="text"
              inputmode="numeric"
              maxlength="1"
              required
            />
          </div>

          <p class="otp-error" id="otpError" hidden></p>
          <p class="otp-success" id="otpSuccess" hidden></p>

          <button type="submit" class="login-submit">
            Verify OTP
            <i class="fa-solid fa-circle-check" aria-hidden="true"></i>
          </button>

          <div class="otp-resend-row">
            <span>Didn't receive the code?</span>
            <button type="button" class="otp-resend" id="otpResend">
              Resend OTP
            </button>
            <span class="otp-timer" id="otpTimer"></span>
          </div>

          <a href="#login" class="otp-back-login" id="otpBackLogin"
            >Back to Login</a
          >
        </form>

        <div class="login-wave" aria-hidden="true">
          <svg viewBox="0 0 420 72" preserveAspectRatio="none">
            <path
              fill="#f3c43a"
              d="M0 26c48 22 86-16 138-4 54 12 78 36 132 26 50-8 82-30 150-6v30H0z"
            />
            <path
              fill="#e8a31a"
              d="M0 42c58 16 92-14 150-4 56 10 88 26 142 14 48-10 72-6 128 10v10H0z"
            />
            <path
              fill="#d97706"
              d="M0 58c72 10 112-8 182 2 56 8 92 12 238 2v10H0z"
            />
          </svg>
        </div>
      </div>
    </dialog>

    <dialog
      class="login-modal"
      id="resetPasswordModal"
      aria-labelledby="reset-password-title"
    >
      <div class="login-card otp-card">
        <button
          type="button"
          class="login-modal-close"
          id="resetPasswordModalClose"
          aria-label="Close set new password"
        >
          <i class="fa-solid fa-xmark" aria-hidden="true"></i>
        </button>

        <header class="login-card-head">
          <span class="login-lock" aria-hidden="true">
            <i class="fa-solid fa-key"></i>
          </span>
          <div>
            <h2 id="reset-password-title">Set New Password</h2>
            <p class="login-tagline">Create a new password for your account</p>
          </div>
        </header>

        <p class="reset-hint">
          Your mobile number has been verified. Enter a new password to
          continue.
        </p>

        <form class="login-form" id="resetPasswordForm">
          <div class="login-field">
            <i class="fa-solid fa-lock login-field-icon" aria-hidden="true"></i>
            <label class="visually-hidden" for="resetPassword"
              >New Password</label
            >
            <input
              id="resetPassword"
              type="password"
              name="password"
              placeholder="New Password"
              autocomplete="new-password"
              minlength="6"
              required
            />
            <button
              type="button"
              class="login-password-toggle"
              data-password-toggle="resetPassword"
              aria-label="Show password"
            >
              <i class="fa-regular fa-eye-slash" aria-hidden="true"></i>
            </button>
          </div>

          <div class="login-field">
            <i class="fa-solid fa-lock login-field-icon" aria-hidden="true"></i>
            <label class="visually-hidden" for="resetPasswordConfirm"
              >Confirm New Password</label
            >
            <input
              id="resetPasswordConfirm"
              type="password"
              name="confirm"
              placeholder="Confirm New Password"
              autocomplete="new-password"
              minlength="6"
              required
            />
            <button
              type="button"
              class="login-password-toggle"
              data-password-toggle="resetPasswordConfirm"
              aria-label="Show password"
            >
              <i class="fa-regular fa-eye-slash" aria-hidden="true"></i>
            </button>
          </div>

          <p class="otp-error" id="resetPasswordError" hidden></p>
          <p class="otp-success" id="resetPasswordSuccess" hidden></p>

          <button type="submit" class="login-submit">
            Save Password
            <i class="fa-solid fa-check" aria-hidden="true"></i>
          </button>

          <a href="#login" class="otp-back-login" id="resetBackLogin"
            >Back to Login</a
          >
        </form>

        <div class="login-wave" aria-hidden="true">
          <svg viewBox="0 0 420 72" preserveAspectRatio="none">
            <path
              fill="#f3c43a"
              d="M0 26c48 22 86-16 138-4 54 12 78 36 132 26 50-8 82-30 150-6v30H0z"
            />
            <path
              fill="#e8a31a"
              d="M0 42c58 16 92-14 150-4 56 10 88 26 142 14 48-10 72-6 128 10v10H0z"
            />
            <path
              fill="#d97706"
              d="M0 58c72 10 112-8 182 2 56 8 92 12 238 2v10H0z"
            />
          </svg>
        </div>
      </div>
    </dialog>

    <dialog
      class="login-modal register-modal"
      id="registerModal"
      aria-labelledby="register-title"
    >
      <div class="register-card">
        <button
          type="button"
          class="login-modal-close"
          id="registerModalClose"
          aria-label="Close registration"
        >
          <i class="fa-solid fa-xmark" aria-hidden="true"></i>
        </button>

        <header class="register-card-head">
          <span class="register-user-icon" aria-hidden="true">
            <i class="fa-solid fa-user-plus"></i>
          </span>
          <h2 id="register-title">Create Your Account</h2>
          <p>Sign up to get started with IBNCC</p>
        </header>

        <form class="register-form" id="registerForm">
          <div class="register-field">
            <i class="fa-solid fa-user" aria-hidden="true"></i>
            <div class="register-field-body">
              <label for="registerName">Name</label>
              <input
                id="registerName"
                type="text"
                name="name"
                placeholder="Enter your full name"
                autocomplete="name"
                required
              />
            </div>
          </div>

          <div class="register-field">
            <i class="fa-solid fa-church" aria-hidden="true"></i>
            <div class="register-field-body">
              <label for="registerParish">Parish</label>
              <input
                id="registerParish"
                type="text"
                name="parish"
                placeholder="Enter your parish"
                required
              />
            </div>
          </div>

          <div class="register-field">
            <i class="fa-solid fa-shield-halved" aria-hidden="true"></i>
            <div class="register-field-body">
              <label for="registerDiocese">Diocese</label>
              <select id="registerDiocese" name="diocese" required>
                <option value="" disabled selected>Select your diocese</option>
                <option value="kozhikode">Kozhikode</option>
                <option value="ernakulam">Ernakulam-Angamaly</option>
                <option value="thrissur">Thrissur</option>
                <option value="kannur">Kannur</option>
                <option value="palakkad">Palakkad</option>
                <option value="thamarassery">Thamarassery</option>
              </select>
            </div>
            <i
              class="fa-solid fa-chevron-down register-chevron"
              aria-hidden="true"
            ></i>
          </div>

          <div class="register-field">
            <i class="fa-solid fa-cross" aria-hidden="true"></i>
            <div class="register-field-body">
              <label for="registerRite">Rite</label>
              <select id="registerRite" name="rite" required>
                <option value="" disabled selected>Select your rite</option>
                <option value="syro-malabar">Syro-Malabar</option>
                <option value="syro-malankara">Syro-Malankara</option>
                <option value="latin">Latin</option>
              </select>
            </div>
            <i
              class="fa-solid fa-chevron-down register-chevron"
              aria-hidden="true"
            ></i>
          </div>

          <div class="register-field">
            <i class="fa-solid fa-lock" aria-hidden="true"></i>
            <div class="register-field-body">
              <label for="registerPassword">Password</label>
              <input
                id="registerPassword"
                type="password"
                name="password"
                placeholder="Enter your password"
                autocomplete="new-password"
                required
              />
            </div>
            <button
              type="button"
              class="login-password-toggle"
              data-password-toggle="registerPassword"
              aria-label="Show password"
            >
              <i class="fa-regular fa-eye-slash" aria-hidden="true"></i>
            </button>
          </div>

          <div class="register-field">
            <i class="fa-solid fa-lock" aria-hidden="true"></i>
            <div class="register-field-body">
              <label for="registerConfirm">Confirm Password</label>
              <input
                id="registerConfirm"
                type="password"
                name="confirm"
                placeholder="Confirm your password"
                autocomplete="new-password"
                required
              />
            </div>
            <button
              type="button"
              class="login-password-toggle"
              data-password-toggle="registerConfirm"
              aria-label="Show password"
            >
              <i class="fa-regular fa-eye-slash" aria-hidden="true"></i>
            </button>
          </div>

          <div class="register-verify-group" data-verify-type="phone">
            <div
              class="register-field register-field--verify"
              id="registerPhoneField"
            >
              <i class="fa-solid fa-phone" aria-hidden="true"></i>
              <div class="register-field-body">
                <label for="registerPhone">Phone Number</label>
                <input
                  id="registerPhone"
                  type="tel"
                  name="phone"
                  placeholder="Enter your phone number"
                  autocomplete="tel"
                  required
                />
              </div>
              <button
                type="button"
                class="register-verify-btn"
                id="registerPhoneVerifyBtn"
                hidden
              >
                Verify
              </button>
              <span
                class="register-verified-badge"
                id="registerPhoneVerified"
                hidden
                aria-live="polite"
              >
                <i class="fa-solid fa-circle-check" aria-hidden="true"></i>
                Verified
              </span>
            </div>
            <div class="register-inline-otp" id="registerPhoneOtpPanel" hidden>
              <p class="register-inline-otp-hint">
                Enter the OTP sent to your phone number
              </p>
              <div class="register-inline-otp-row">
                <label class="visually-hidden" for="registerPhoneOtpInput"
                  >Phone OTP</label
                >
                <input
                  id="registerPhoneOtpInput"
                  class="register-inline-otp-input"
                  type="text"
                  inputmode="numeric"
                  maxlength="6"
                  autocomplete="one-time-code"
                  placeholder="Enter 6-digit OTP"
                />
                <button
                  type="button"
                  class="register-otp-confirm"
                  id="registerPhoneOtpConfirm"
                >
                  Confirm
                </button>
              </div>
              <p
                class="register-inline-otp-demo"
                id="registerPhoneOtpDemo"
                hidden
              ></p>
              <p
                class="register-inline-otp-msg"
                id="registerPhoneOtpMsg"
                hidden
              ></p>
            </div>
          </div>

          <div class="register-verify-group" data-verify-type="email">
            <div
              class="register-field register-field--verify"
              id="registerEmailField"
            >
              <i class="fa-solid fa-envelope" aria-hidden="true"></i>
              <div class="register-field-body">
                <label for="registerEmail">Email (Optional)</label>
                <input
                  id="registerEmail"
                  type="email"
                  name="email"
                  placeholder="Enter your email address"
                  autocomplete="email"
                />
              </div>
              <button
                type="button"
                class="register-verify-btn"
                id="registerEmailVerifyBtn"
                hidden
              >
                Verify
              </button>
              <span
                class="register-verified-badge"
                id="registerEmailVerified"
                hidden
                aria-live="polite"
              >
                <i class="fa-solid fa-circle-check" aria-hidden="true"></i>
                Verified
              </span>
            </div>
            <div class="register-inline-otp" id="registerEmailOtpPanel" hidden>
              <p class="register-inline-otp-hint">
                Enter the OTP sent to your email address
              </p>
              <div class="register-inline-otp-row">
                <label class="visually-hidden" for="registerEmailOtpInput"
                  >Email OTP</label
                >
                <input
                  id="registerEmailOtpInput"
                  class="register-inline-otp-input"
                  type="text"
                  inputmode="numeric"
                  maxlength="6"
                  autocomplete="one-time-code"
                  placeholder="Enter 6-digit OTP"
                />
                <button
                  type="button"
                  class="register-otp-confirm"
                  id="registerEmailOtpConfirm"
                >
                  Confirm
                </button>
              </div>
              <p
                class="register-inline-otp-demo"
                id="registerEmailOtpDemo"
                hidden
              ></p>
              <p
                class="register-inline-otp-msg"
                id="registerEmailOtpMsg"
                hidden
              ></p>
            </div>
          </div>

          <button type="submit" class="login-submit register-submit">
            <i class="fa-solid fa-user-plus" aria-hidden="true"></i>
            Sign Up
          </button>

          <div class="login-divider">OR</div>

          <button type="button" class="register-google" id="registerGoogleBtn">
            <svg viewBox="0 0 48 48" width="20" height="20" aria-hidden="true">
              <path
                fill="#FFC107"
                d="M43.6 20.5H42V20H24v8h11.3C33.6 32.4 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 8 3.1l5.7-5.7C34.2 6.1 29.4 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.7-.4-3.5z"
              />
              <path
                fill="#FF3D00"
                d="M6.3 14.7l6.6 4.8C14.7 16 19 12 24 12c3.1 0 5.8 1.2 8 3.1l5.7-5.7C34.2 6.1 29.4 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"
              />
              <path
                fill="#4CAF50"
                d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.5-11.2-8.3l-6.5 5C9.6 39.6 16.3 44 24 44z"
              />
              <path
                fill="#1976D2"
                d="M43.6 20.5H42V20H24v8h11.3c-1.1 3.2-3.5 5.8-6.6 7.3l6.2 5.2C37.5 38.3 44 33 44 24c0-1.3-.1-2.7-.4-3.5z"
              />
            </svg>
            Sign up with Google
          </button>

          <p class="register-legal">
            By signing up, you agree to our<br />
            <a href="#terms">Terms of Use</a>
            <span>| and</span>
            <a href="#privacy">Privacy Policy</a>
          </p>
        </form>
      </div>
    </dialog>

    <!-- IBNCC scripts (header behavior, sticky header, mobile menu) -->
    <script src="js/script.js" defer></script>
    <!-- CC_Hub scripts (networking directory functionality) -->
    <script src="js/cchub/ch-main.js" defer></script>
    <!-- CC_Hub login scripts -->
    <script src="js/cchub/ch-login.js" defer></script>
  </body>
</html>
