<?php
    $headerNotice = \App\Models\HeaderNotice::where('is_active', true)->latest()->first();
?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($headerNotice): ?>
<span class="header-notice-track">
    <span class="header-notice-marquee">
        <span class="header-notice-text"><?php echo e($headerNotice->text); ?></span>
        <span class="header-notice-text" aria-hidden="true"><?php echo e($headerNotice->text); ?></span>
    </span>
</span>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?><?php /**PATH C:\Users\USER-NBT\Desktop\ibncc_project\resources\views/partials/header-notice.blade.php ENDPATH**/ ?>