
 <nav class="category-nav" aria-label="Product categories">
    <div class="category-nav-inner">

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="category-dropdown"
                 data-mega="<?php echo e($category->slug); ?>">

                <a href="<?php echo e(url('/products')); ?>?cat=<?php echo e($category->slug); ?>"
                   class="category-item">

                    <span class="category-icon">
                        <i class="<?php echo e($category->image ?? 'fa-solid fa-list'); ?>"></i>
                    </span>

                    <span class="category-label">
                        <?php echo e($category->name); ?>

                    </span>

                    <i class="fa-solid fa-chevron-down category-chevron"
                       aria-hidden="true"></i>
                </a>

                <div class="mega-menu" role="menu">
                    <div class="mega-menu-scroll">
                        <div class="mega-menu-shell">

                            
                            <aside class="mega-featured">
                                <p class="mega-featured-eyebrow">
                                    Shop <?php echo e($category->name); ?>

                                </p>

                                <h3 class="mega-featured-title">
                                    <?php echo e($category->name); ?>

                                </h3>

                                <p class="mega-featured-subtitle">
                                    Explore our <?php echo e(strtolower($category->name)); ?> collection.
                                </p>

                                <a href="<?php echo e(url('/products')); ?>?cat=<?php echo e($category->slug); ?>"
                                   class="mega-featured-cta">
                                    Shop Now
                                    <i class="fa-solid fa-arrow-right"></i>
                                </a>
                            </aside>

                            
                            <div class="mega-columns">

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <div class="mega-col">
                                        <div class="mega-group">

                                            <a href="<?php echo e(url('/products')); ?>?cat=<?php echo e($category->slug); ?>&group=<?php echo e($group->slug); ?>"
                                               class="mega-heading">

                                                <span class="mega-heading-icon">
                                                    <i class="<?php echo e($group->icon ?? 'fa-solid fa-angle-right'); ?>"></i>
                                                </span>

                                                <span class="mega-heading-text">
                                                    <?php echo e($group->name); ?>

                                                </span>

                                                <i class="fa-solid fa-chevron-right mega-heading-chevron"></i>
                                            </a>

                                            
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($group->children->isNotEmpty()): ?>
                                                <ul class="mega-list">

                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $group->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li>
                                                            <a href="<?php echo e(url('/products')); ?>?cat=<?php echo e($category->slug); ?>&group=<?php echo e($group->slug); ?>&item=<?php echo e($item->slug); ?>">
                                                                <?php echo e($item->name); ?>

                                                            </a>
                                                        </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                                </ul>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                        </div>
                                    </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                            </div>

                        </div>
                    </div>
                </div>

            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    </div>
</nav><?php /**PATH C:\Users\USER-NBT\Desktop\ibncc_project\resources\views/trading/navbar.blade.php ENDPATH**/ ?>