<?php
    use Illuminate\Support\Str;

    $isRetail  = $mode === 'retail';
    $pageTitle = $selectedCategory?->name ?? ($isRetail ? 'Products' : 'Trading Products');
    $noImage   = asset('assets/images/no-image.avif');
    $indexUrl  = $isRetail ? route('products.index') : route('trading.products.index');

    // Indian grouping, trailing zeros trimmed (128680 → 1,28,680 | 10.50 → 10.5)
    $inr = function ($n, int $dec = 2): string {
        $n = round((float) $n, $dec);
        [$int, $frac] = array_pad(explode('.', number_format(abs($n), $dec, '.', '')), 2, '');
        $frac = rtrim($frac, '0');
        $last = substr($int, -3);
        $rest = substr($int, 0, -3);
        if ($rest !== '') {
            $rest = preg_replace('/\B(?=(\d{2})+(?!\d))/', ',', $rest) . ',';
        }
        return $rest . $last . ($frac !== '' ? '.' . $frac : '');
    };
    $qty = fn ($q) => rtrim(rtrim(number_format((float) $q, 3, '.', ''), '0'), '.');

    // attribute id → key used in data-filter="…" and data-… on the cards (lowercase, like the HTML)
    $attrKey = [];
    foreach ($filters as $f) {
        $attrKey[$f->id] = str_replace('-', '', Str::lower($f->slug));
    }

    $items = $products instanceof \Illuminate\Pagination\AbstractPaginator
        ? $products->getCollection() : collect($products);
    $total = method_exists($products, 'total') ? $products->total() : $items->count();

    // ---- precompute every card once --------------------------------------
    $cards = $items->map(function ($product) use ($isRetail, $attrKey, $qty, $inr) {
        $variants = $product->variants->where('is_active', true);
        $variant  = $variants->firstWhere('is_default', true) ?? $variants->first();
        $image    = $product->images->firstWhere('is_primary', true) ?? $product->images->first();

        $price = $variant?->price;
        $mrp   = $variant?->mrp;
        $tiers = $product->priceTiers->where('price_type', 'wholesale');
        $low   = $tiers->min('price') ?? $price;
        $high  = $tiers->max('price') ?? $price;
        $disc  = ($isRetail && $mrp && $price && $mrp > $price) ? (int) round((($mrp - $price) / $mrp) * 100) : 0;

        $avail = $variants->sum(fn ($v) => max(0, (float) $v->stock - (float) $v->reserved_stock));
        $inStock = $product->track_stock ? $avail > 0 : true;

        // cat / group / item like the HTML (root slug, 2nd level name, 3rd level name)
        $chain = [];
        for ($c = $product->category; $c; $c = $c->parent) { array_unshift($chain, $c); }
        $catSlug = $chain[0]->slug ?? '';
        $group   = $chain[1]->name ?? ($chain[0]->name ?? '');
        $item    = isset($chain[2]) ? $chain[2]->name : '';

        $attrs = [];
        if ($product->relationLoaded('attributeValues')) {
            foreach ($product->attributeValues as $v) {
                if (isset($attrKey[$v->attribute_id]) && $v->option) {
                    $attrs[$attrKey[$v->attribute_id]][] = $v->option->label;
                }
            }
        }

        return [
            'p' => $product, 'variant' => $variant, 'image' => $image,
            'price' => $price, 'mrp' => $mrp, 'low' => $low, 'high' => $high, 'disc' => $disc,
            'inStock' => $inStock, 'cat' => $catSlug, 'group' => $group, 'item' => $item, 'attrs' => $attrs,
            'specs' => $product->short_description
                ? Str::limit(strip_tags($product->short_description), 90)
                : collect([$product->brand?->name, $product->model_no])->filter()->implode(', '),
            'rating' => rtrim(rtrim(number_format((float) $product->rating_avg, 1), '0'), '.'),
            'url' => $isRetail ? route('products.show', $product->slug) : route('trading.products.show', $product->slug),
        ];
    });

    // price slider bounds from the listed products
    $shown = $cards->map(fn ($c) => $isRetail ? $c['price'] : $c['high'])->filter();
    $bMin  = $shown->isNotEmpty() ? (int) floor($cards->map(fn ($c) => $isRetail ? $c['price'] : $c['low'])->filter()->min()) : 0;
    $bMax  = $shown->isNotEmpty() ? (int) ceil($shown->max()) : 1000;
    $step  = max(1, (int) round(($bMax - $bMin) / 100));

    $subcatBgs = ['#e8eef5', '#eef2f6', '#eaf4fb', '#eef6fb', '#e8f0ea', '#eef0f4', '#eaf3e6', '#fbf6e4'];
?>

<?php $__env->startSection('title'); ?>
    <?php echo e($pageTitle); ?> — CC Hub
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/cchub/ch-product-list.css')); ?>">
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if (! ($isRetail)): ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/cchub/trading-product-list.css')); ?>">
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-class', 'product-list-page' . ($isRetail ? '' : ' trading-product-list-page')); ?>

<?php $__env->startSection('body'); ?>
<?php echo $__env->make('trading.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<main class="pl-main">
    <div class="pl-layout">

        <aside class="pl-sidebar" id="plSidebar" aria-label="Product filters">
            <header class="pl-sidebar-head">
                <h2>Filters</h2>
                <button type="button" class="pl-clear-btn" id="plClearAll">Clear all</button>
                <button type="button" class="pl-sidebar-close" id="plSidebarClose" aria-label="Close filters">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </header>

            <div class="pl-filters" id="plFilters">
                <div class="pl-filter-set" data-preset="default" data-is-fallback="true">

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($brands->isNotEmpty()): ?>
                        <details class="pl-filter-group" open>
                            <summary class="pl-filter-summary">
                                Brand <i class="fa-solid fa-chevron-down"></i>
                            </summary>
                            <div class="pl-filter-body">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="pl-filter-check"><input type="checkbox" data-filter="brand" value="<?php echo e($brand->name); ?>" /><span><?php echo e($brand->name); ?></span></label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </details>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $filters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($filter->options->isNotEmpty()): ?>
                            <details class="pl-filter-group" open>
                                <summary class="pl-filter-summary">
                                    <?php echo e($filter->name); ?> <i class="fa-solid fa-chevron-down"></i>
                                </summary>
                                <div class="pl-filter-body">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $filter->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <label class="pl-filter-check"><input type="checkbox" data-filter="<?php echo e($attrKey[$filter->id]); ?>" value="<?php echo e($option->label); ?>" /><span><?php echo e($option->label); ?></span></label>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                            </details>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <details class="pl-filter-group" open>
                        <summary class="pl-filter-summary">
                            Price Range <i class="fa-solid fa-chevron-down"></i>
                        </summary>
                        <div class="pl-filter-body pl-price-range">
                            <input type="range" min="<?php echo e($bMin); ?>" max="<?php echo e($bMax); ?>" step="<?php echo e($step); ?>" value="<?php echo e($bMax); ?>" data-filter="price" data-range="max" />
                            <div class="pl-price-labels">
                                <span>₹<?php echo e($inr($bMin, 0)); ?></span><span>₹<?php echo e($inr($bMax, 0)); ?></span>
                            </div>
                        </div>
                    </details>

                    <details class="pl-filter-group" open>
                        <summary class="pl-filter-summary">
                            Discount <i class="fa-solid fa-chevron-down"></i>
                        </summary>
                        <div class="pl-filter-body">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = [10, 20, 30, 40]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="pl-filter-check"><input type="checkbox" data-filter="discount" value="<?php echo e($d); ?>% and above" /><span><?php echo e($d); ?>% and above</span></label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </details>

                    <details class="pl-filter-group" open>
                        <summary class="pl-filter-summary">
                            Customer Ratings <i class="fa-solid fa-chevron-down"></i>
                        </summary>
                        <div class="pl-filter-body">
                            <label class="pl-filter-check"><input type="checkbox" data-filter="rating" value="4★ &amp; above" /><span>4★ &amp; above</span></label>
                            <label class="pl-filter-check"><input type="checkbox" data-filter="rating" value="3★ &amp; above" /><span>3★ &amp; above</span></label>
                        </div>
                    </details>

                    <details class="pl-filter-group" open>
                        <summary class="pl-filter-summary">
                            Availability <i class="fa-solid fa-chevron-down"></i>
                        </summary>
                        <div class="pl-filter-body">
                            <label class="pl-filter-check"><input type="checkbox" data-filter="availability" value="In Stock" /><span>In Stock</span></label>
                            <label class="pl-filter-check"><input type="checkbox" data-filter="availability" value="Out of Stock" /><span>Out of Stock</span></label>
                        </div>
                    </details>
                </div>
            </div>
        </aside>

        <div class="pl-content">
            <nav class="pl-breadcrumb" id="plBreadcrumb" aria-label="Breadcrumb">
                <a href="<?php echo e(url('/')); ?>">Home</a><span aria-hidden="true">›</span>
                <span aria-current="page"><?php echo e($pageTitle); ?></span>
            </nav>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isRetail): ?>
                <section class="pl-subcat-gallery" id="plSubcatGallery" aria-label="Shop by subcategory" hidden>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($category->children->isNotEmpty()): ?>
                            <div class="pl-subcat-set" data-cat="<?php echo e($category->slug); ?>" hidden>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $imgs = collect($child->preview_images ?? [])->filter()->take(4)->values();
                                        if ($imgs->isEmpty()) {
                                            $imgs = collect([$child->image ? asset('storage/' . $child->image) : $noImage]);
                                        }
                                    ?>
                                    <a href="<?php echo e($indexUrl); ?>?<?php echo e(http_build_query(['cat' => $category->slug, 'group' => $child->name])); ?>" class="pl-subcat-card" style="--card-bg:<?php echo e($subcatBgs[$loop->index % count($subcatBgs)]); ?>">
                                        <div class="pl-subcat-media">
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $imgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $src): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <img src="<?php echo e($src); ?>" alt="" loading="lazy" width="100" height="100" />
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </div>
                                        <div class="pl-subcat-footer">
                                            <strong><?php echo e($child->name); ?></strong>
                                            <span>Explore <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></span>
                                        </div>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </section>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <header class="pl-head">
                <h1 id="plTitle"><?php echo e($pageTitle); ?></h1>
                <p class="pl-count" id="plCount">(Showing <?php echo e($total); ?> products)</p>
            </header>

            <div class="pl-toolbar">
                <div class="pl-applied-wrap">
                    <span class="pl-applied-label">Sorted By / Applied Filters</span>
                    <div class="pl-applied" id="plApplied">
                        <span class="pl-applied-empty">No filters applied</span>
                    </div>
                </div>
                <div class="pl-sort-wrap">
                    <span class="pl-sort-label">Sort By</span>
                    <div class="pl-sort-tabs" id="plSortTabs" role="tablist">
                        <button type="button" class="pl-sort-tab" data-sort="relevance" role="tab">Relevance</button>
                        <button type="button" class="pl-sort-tab is-active" data-sort="popularity" role="tab">Popularity</button>
                        <button type="button" class="pl-sort-tab" data-sort="price-asc" role="tab">Price — Low to High</button>
                        <button type="button" class="pl-sort-tab" data-sort="price-desc" role="tab">Price — High to Low</button>
                        <button type="button" class="pl-sort-tab" data-sort="rating" role="tab">Customer Rating</button>
                        <button type="button" class="pl-sort-tab" data-sort="newest" role="tab">Newest</button>
                    </div>
                </div>
            </div>

            <div class="pl-grid" id="plGrid" aria-live="polite">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $product = $c['p']; ?>
                    <article
                        class="pl-card"
                        data-id="<?php echo e($product->id); ?>"
                        data-cat="<?php echo e($c['cat']); ?>"
                        data-group="<?php echo e($c['group']); ?>"
                        data-item="<?php echo e($c['item']); ?>"
                        data-brand="<?php echo e($product->brand?->name); ?>"
                        data-price="<?php echo e($isRetail ? $c['price'] : $c['low']); ?>"
                        <?php if (! ($isRetail)): ?> data-price-max="<?php echo e($c['high']); ?>" data-moq="<?php echo e($qty($product->min_order_qty)); ?>" <?php endif; ?>
                        data-mrp="<?php echo e($isRetail ? $c['mrp'] : $c['high']); ?>"
                        data-discount="<?php echo e($c['disc']); ?>"
                        data-rating="<?php echo e($product->rating_avg + 0); ?>"
                        data-reviews="<?php echo e($product->rating_count); ?>"
                        data-availability="<?php echo e($c['inStock'] ? 'In Stock' : 'Out of Stock'); ?>"
                        <?php $__currentLoopData = $c['attrs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $vals): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> data-<?php echo e($k); ?>="<?php echo e(implode(', ', array_unique($vals))); ?>" <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if (! ($isRetail)): ?> data-categories="Wholesale" <?php endif; ?>
                    >
                        <button type="button" class="pl-wishlist" data-wish="<?php echo e($product->id); ?>" aria-label="Add to wishlist">
                            <i class="fa-regular fa-heart"></i>
                        </button>
                        <div class="pl-card-img-wrap">
                            <img src="<?php echo e($c['image'] ? asset('storage/' . $c['image']->path) : $noImage); ?>" alt="<?php echo e($c['image']?->alt ?? $product->title); ?>" loading="lazy" />
                        </div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isRetail && $product->is_featured): ?>
                            <span class="pl-sponsored">Sponsored</span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <h3 class="pl-card-title">
                            <a href="<?php echo e($c['url']); ?>"><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! $isRetail && ($product->is_assured || $product->offer_text)): ?><span class="pl-super-badge" aria-label="Super"><i class="fa-solid fa-bolt" aria-hidden="true"></i> <?php echo e($product->offer_text ?: 'Super'); ?></span> <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?><?php echo e($product->title); ?></a>
                        </h3>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($c['specs']): ?>
                            <p class="pl-card-specs"><?php echo e($c['specs']); ?></p>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <div class="pl-rating-row">
                            <span class="pl-rating-badge"><?php echo e($c['rating']); ?> <i class="fa-solid fa-star"></i></span>
                            <span class="pl-reviews">(<?php echo e($inr($product->rating_count, 0)); ?>)</span>
                        </div>
                        <div class="pl-price-row">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isRetail): ?>
                                <span class="pl-price">₹<?php echo e($inr($c['price'])); ?></span>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($c['disc'] > 0): ?>
                                    <span class="pl-mrp">₹<?php echo e($inr($c['mrp'])); ?></span>
                                    <span class="pl-discount"><?php echo e($c['disc']); ?>% off</span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <?php else: ?>
                                <span class="pl-price">₹<?php echo e($inr($c['low'])); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($c['high'] && $c['high'] != $c['low']): ?>-<?php echo e($inr($c['high'])); ?><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></span>
                                <span class="pl-moq">MOQ: <?php echo e($qty($product->min_order_qty)); ?></span>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isRetail): ?>
                            <p class="pl-stock <?php echo e($c['inStock'] ? 'is-in' : 'is-out'); ?>"><?php echo e($c['inStock'] ? 'In Stock' : 'Out of Stock'); ?></p>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <div class="pl-card-actions">
                            <button type="button" class="pl-btn-cart" data-cart="<?php echo e($product->id); ?>">Add to Cart</button>
                            <a class="pl-btn-view" href="<?php echo e($c['url']); ?>">View Details</a>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
            <p class="pl-empty" id="plEmpty" <?php if($cards->isNotEmpty()): ?> hidden <?php endif; ?>>
                No products match your filters. Try adjusting or clearing filters.
            </p>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($products instanceof \Illuminate\Contracts\Pagination\Paginator): ?>
                <div class="pl-pagination"><?php echo e($products->withQueryString()->links()); ?></div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>

    <button type="button" class="pl-filters-fab" id="plFiltersFab">
        <i class="fa-solid fa-sliders" aria-hidden="true"></i>
        Filters
    </button>
    <div class="pl-sidebar-backdrop" id="plSidebarBackdrop" hidden></div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/cchub/ch-mega-menu.js')); ?>"></script>
    <script src="<?php echo e(asset('js/cchub/ch-login.js')); ?>"></script>
    <script src="<?php echo e(asset('js/cchub/ch-product-list.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.trading', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER-NBT\Desktop\ibncc_project\resources\views/catalog/listing.blade.php ENDPATH**/ ?>