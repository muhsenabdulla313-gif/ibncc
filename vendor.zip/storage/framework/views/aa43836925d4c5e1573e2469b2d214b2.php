
<section class="section events-gallery" id="events">
  <div class="container">

    <!-- Upcoming Events -->
    <div class="events-subsection events-upcoming">
      <div class="section-header section-header-upc reveal">
        <p class="section-eyebrow">Calendar</p>
        <h2 class="section-title">Upcoming Events</h2>
        <p class="section-lead">
          Join us for high-impact gatherings that connect Christian business leaders across the globe.
        </p>
      </div>

      <div class="upcoming-gallery">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = \App\Models\Event::upcoming()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <article class="upcoming-card reveal" data-stagger="<?php echo e($loop->index); ?>">
            <div class="upcoming-card-media">
              <img src="<?php echo e($e->cover_url); ?>" alt="<?php echo e($e->title); ?>" loading="lazy" width="900" height="520" />
              <span class="upcoming-badge">Upcoming</span>
            </div>
            <div class="upcoming-card-body">
              <h3 class="upcoming-card-title"><?php echo e($e->title); ?></h3>
              <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($e->tagline): ?>
                <p class="upcoming-card-tagline"><?php echo e($e->tagline); ?></p>
              <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
              <ul class="upcoming-card-meta">
                <li>
                  <i class="fa-regular fa-calendar" aria-hidden="true"></i>
                  <span><?php echo e($e->event_date->format('jS F Y')); ?></span>
                </li>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($e->venue): ?>
                  <li>
                    <i class="fa-solid fa-location-dot" aria-hidden="true"></i>
                    <span><?php echo e($e->venue); ?></span>
                  </li>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
              </ul>
              <a href="<?php echo e(route('events.show', $e->slug)); ?>" class="btn btn-primary upcoming-card-btn">
                View Details <i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
              </a>
            </div>
          </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <p class="section-lead">No upcoming events right now. Please check back soon.</p>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
      </div>
    </div>

    <!-- Previous Events -->
    <div class="events-subsection events-previous">
      <div class="section-header reveal">
        <p class="section-eyebrow">Archive</p>
        <h2 class="section-title">Previous Events</h2>
        <p class="section-lead">
          Highlights from past conclaves, forums and networking gatherings across the IBNCC community.
        </p>
      </div>

      <div class="previous-gallery">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = \App\Models\Event::previous()->with('images')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <article class="previous-card reveal" data-stagger="<?php echo e($loop->index); ?>" tabindex="0" aria-haspopup="dialog">
            <template class="previous-card-slides">
              <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $e->slide_urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="<?php echo e($u); ?>" alt="<?php echo e($e->title); ?>" />
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </template>
            <div class="previous-card-media">
              <img src="<?php echo e($e->cover_url); ?>" alt="<?php echo e($e->title); ?>" loading="lazy" width="480" height="320" />
              <div class="previous-card-overlay">
                <div class="previous-card-details">
                  <p>
                    <i class="fa-regular fa-calendar" aria-hidden="true"></i>
                    <?php echo e($e->event_date->format('jS F Y')); ?>

                  </p>
                  <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($e->city): ?>
                    <p>
                      <i class="fa-solid fa-location-dot" aria-hidden="true"></i>
                      <?php echo e($e->city); ?>

                    </p>
                  <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
              </div>
            </div>
            <div class="previous-card-body">
              <h3><?php echo e($e->title); ?></h3>
              <a href="#" class="btn btn-hero-secondary previous-card-btn">
                View More <i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
              </a>
            </div>
          </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
      </div>
    </div>

  </div>
</section>
<?php /**PATH C:\Users\USER-NBT\Desktop\ibncc_project\resources\views/partials/events-section.blade.php ENDPATH**/ ?>